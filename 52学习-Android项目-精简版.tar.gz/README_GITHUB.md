# 📱 52学习 - Android APP

## 🎯 项目概述
将在线学习平台 `www.52xuexi.art` 打包为Android移动应用。

## 🚀 特性
- 📚 完整在线学习平台
- 🎥 视频播放支持
- 📊 学习进度同步
- ⬇️ 课程资料下载
- 🔗 深度链接支持

## 🏗️ 构建说明

### 自动构建
本项目配置了GitHub Actions，每次推送代码会自动构建APK。

### 本地构建
```bash
./gradlew assembleDebug    # 调试版
./gradlew assembleRelease  # 发布版
```

### 系统要求
- Android 5.0+ (API 21+)
- 网络连接
- 存储权限（下载功能）

## 📱 安装使用
1. 下载APK文件
2. 允许安装未知来源应用
3. 点击安装
4. 打开"52学习"APP

## 🎯 技术栈
- WebView + Kotlin
- Material Design
- Android SDK 27
- Gradle 4.4.1
