#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import qrcode
from PIL import Image, ImageDraw, ImageFont
import os

def create_app_qr_code():
    """创建52学习APP下载二维码"""
    
    # APP下载链接
    app_url = "http://52xuexi.art/52学习.apk"
    
    print("🔲 生成52学习APP下载二维码...")
    print(f"📱 APP下载链接: {app_url}")
    
    # 创建二维码
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4,
    )
    qr.add_data(app_url)
    qr.make(fit=True)
    
    # 生成二维码图片
    qr_img = qr.make_image(fill_color="black", back_color="white")
    
    # 创建带logo和文字的二维码
    img_size = 300
    final_img = Image.new('RGB', (img_size, img_size + 60), 'white')
    
    # 调整二维码大小
    qr_img = qr_img.resize((img_size - 40, img_size - 40))
    
    # 将二维码贴到中心
    final_img.paste(qr_img, (20, 20))
    
    # 添加文字
    draw = ImageDraw.Draw(final_img)
    
    # 尝试使用系统字体
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 16)
    except:
        font = ImageFont.load_default()
    
    # 添加标题
    title_text = "52学习 Android APP"
    text_bbox = draw.textbbox((0, 0), title_text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    title_x = (img_size - text_width) // 2
    draw.text((title_x, img_size - 40), title_text, fill="black", font=font)
    
    # 添加副标题
    subtitle_text = "扫码下载安装"
    text_bbox = draw.textbbox((0, 0), subtitle_text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    subtitle_x = (img_size - text_width) // 2
    draw.text((subtitle_x, img_size - 20), subtitle_text, fill="gray", font=font)
    
    # 保存到web目录
    web_dir = "/home/online-learning-platform/dist"
    qr_path = os.path.join(web_dir, "52学习-APP下载二维码.png")
    final_img.save(qr_path)
    
    print(f"✅ 二维码已生成: {qr_path}")
    print(f"🌐 访问地址: http://52xuexi.art/52学习-APP下载二维码.png")
    
    # 创建小尺寸版本（用于网站集成）
    small_img = final_img.resize((150, 180))
    small_qr_path = os.path.join(web_dir, "app-qr-small.png")
    small_img.save(small_qr_path)
    
    print(f"📱 小尺寸二维码: http://52xuexi.art/app-qr-small.png")
    
    return qr_path, small_qr_path

def create_website_qr_code():
    """创建网站二维码"""
    
    website_url = "http://52xuexi.art"
    
    print("🌐 生成网站访问二维码...")
    
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=3,
    )
    qr.add_data(website_url)
    qr.make(fit=True)
    
    qr_img = qr.make_image(fill_color="black", back_color="white")
    
    # 保存网站二维码
    web_dir = "/home/online-learning-platform/dist"
    website_qr_path = os.path.join(web_dir, "网站二维码.png")
    qr_img.save(website_qr_path)
    
    print(f"✅ 网站二维码已生成: http://52xuexi.art/网站二维码.png")
    
    return website_qr_path

if __name__ == "__main__":
    print("======================================")
    print("  52学习 - 二维码生成工具")
    print("======================================")
    print()
    
    # 生成APP下载二维码
    app_qr, app_qr_small = create_app_qr_code()
    print()
    
    # 生成网站二维码
    website_qr = create_website_qr_code()
    print()
    
    print("🎉 所有二维码生成完成！")
    print()
    print("📱 APP下载二维码:")
    print(f"   大尺寸: http://52xuexi.art/52学习-APP下载二维码.png")
    print(f"   小尺寸: http://52xuexi.art/app-qr-small.png")
    print()
    print("🌐 网站访问二维码:")
    print(f"   网站码: http://52xuexi.art/网站二维码.png")
    print()
    print("✅ 可以集成到网站中使用！")
