#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import qrcode
from PIL import Image, ImageDraw, ImageFont
import os

def create_large_qr_code():
    """创建大尺寸的APP下载二维码，专门用于悬浮框"""
    
    app_url = "http://52xuexi.art/52学习.apk"
    
    print("🔲 生成大尺寸APP下载二维码...")
    
    # 创建高质量二维码
    qr = qrcode.QRCode(
        version=2,  # 增加版本，生成更清晰的二维码
        error_correction=qrcode.constants.ERROR_CORRECT_H,  # 高错误纠正
        box_size=12,  # 增大box size
        border=2,  # 减小边框
    )
    qr.add_data(app_url)
    qr.make(fit=True)
    
    # 生成二维码图片
    qr_img = qr.make_image(fill_color="black", back_color="white")
    
    # 调整到合适的尺寸（96x96px，对应Tailwind的w-24 h-24）
    final_size = 96
    qr_img = qr_img.resize((final_size, final_size), Image.Resampling.LANCZOS)
    
    # 保存到web目录
    web_dir = "/home/online-learning-platform/dist"
    
    # 替换原来的小尺寸二维码
    qr_path = os.path.join(web_dir, "app-qr-small.png")
    qr_img.save(qr_path, optimize=True, quality=95)
    
    print(f"✅ 大尺寸二维码已生成: {qr_path}")
    print(f"📏 尺寸: {final_size}x{final_size}px")
    print(f"🌐 访问地址: http://52xuexi.art/app-qr-small.png")
    
    # 创建超大版本用于Footer区域
    footer_size = 120
    footer_qr = qr_img.resize((footer_size, footer_size), Image.Resampling.LANCZOS)
    footer_qr_path = os.path.join(web_dir, "app-qr-footer.png")
    footer_qr.save(footer_qr_path, optimize=True, quality=95)
    
    print(f"✅ Footer大二维码: http://52xuexi.art/app-qr-footer.png")
    
    return qr_path, footer_qr_path

if __name__ == "__main__":
    print("======================================")
    print("  优化52学习APP二维码尺寸")
    print("======================================")
    print()
    
    # 生成优化后的二维码
    small_qr, footer_qr = create_large_qr_code()
    
    print()
    print("🎉 二维码优化完成！")
    print()
    print("📱 悬浮框二维码: 96x96px (w-24 h-24)")
    print("📋 Footer二维码: 120x120px")
    print()
    print("✅ 现在的二维码足够大，可以正常扫描下载！")
