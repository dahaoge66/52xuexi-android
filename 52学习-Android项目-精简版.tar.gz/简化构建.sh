#!/bin/bash

echo "========================================"
echo "  52学习APP - 简化构建方案"
echo "========================================"

# 设置环境
export ANDROID_HOME=/home/android-sdk
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$PATH:$ANDROID_HOME/tools/bin:$ANDROID_HOME/platform-tools

echo "🔧 环境配置:"
echo "ANDROID_HOME=$ANDROID_HOME"
echo "JAVA_HOME=$JAVA_HOME"
echo

# 创建简化的gradle.properties
cat > gradle.properties << EOF
org.gradle.jvmargs=-Xmx1536m
android.useDeprecatedNdk=true
android.enableJetifier=true
android.useAndroidX=true
android.suppressUnsupportedCompileSdk=27
EOF

# 创建local.properties
echo "sdk.dir=$ANDROID_HOME" > local.properties

# 清理之前的构建
echo "🧹 清理旧构建..."
rm -rf app/build .gradle

# 使用系统gradle构建
echo "🏗️ 开始构建52学习APP..."
echo

# 直接使用gradle构建
gradle clean
gradle assembleDebug --stacktrace

# 检查结果
APK_PATH="app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
    echo
    echo "🎉 52学习APP构建成功！"
    echo "📱 APK位置: $APK_PATH"
    echo "📦 APK大小: $(du -h "$APK_PATH" | cut -f1)"
    
    # 复制到web目录
    if [ -d "/home/online-learning-platform/dist" ]; then
        cp "$APK_PATH" "/home/online-learning-platform/dist/52学习.apk"
        echo "🌐 Web下载: http://52xuexi.art/52学习.apk"
    fi
    
    echo
    echo "📲 安装方法:"
    echo "1. 手机打开: http://52xuexi.art/52学习.apk"
    echo "2. 下载并安装APK"
    echo "3. 打开'52学习'APP"
    echo
    echo "✅ 52学习APP已完成！"
    
else
    echo "❌ 构建失败，检查错误信息"
    exit 1
fi
